package com.wipro.wicruit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;

public class StudentRegisterScreen extends AppCompatActivity {

    DatabaseClass myDB;


    Button goEventsHome;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_register_screen);

        myDB = new DatabaseClass(this);


        RelativeLayout rlayout = (RelativeLayout) findViewById(R.id.mainlayout);
        rlayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StudentRegisterScreen.this, StudentRegistration.class);
                startActivity(intent);
            }
        });


        goEventsHome = (Button) findViewById(R.id.HomeBtn);
        goEventsHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goHome = new Intent(StudentRegisterScreen.this, AdminCheck.class);
                startActivity(goHome);
            }
        });

    }

}




