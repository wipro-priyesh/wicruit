package com.wipro.wicruit;

import android.app.Application;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by PA391006 on 05/10/2017.
 */




public class DatabaseClass extends SQLiteOpenHelper {


    public String EventTableName;


    public static final String DATABASE_NAME = "test.db";
    public static final String EVENTS_TABLE_NAME = "events_table";
    public static final String STUDENT_TABLE_NAME = "student_table";
    private static final String USER_TABLE_NAME = "UserTable";

    private static final String ID = "ID";
    private static final String EMAIL = "EMAIL";
    private static final String PASSWORD = "PASSWORD";

    public static final String Event_Table_COL_0 = "ID";
    public static final String Event_Table_COL_1 = "TITLE";
    public static final String Event_Table_COL_2 = "TYPE";
    public static final String Event_Table_COL_3 = "LOCATION";
    public static final String Event_Table_COL_4 = "STARTDATE";
    public static final String Event_Table_COL_5 = "EVENTSTATUS";
    public static final String Event_Table_COL_6 = "EVENTATTENDED";

    public static final String Student_Table_COL_1 = "ID";
    public static final String Student_Table_COL_2 = "FIRSTNAME";
    public static final String Student_Table_COL_3 = "SURNAME";
    public static final String Student_Table_COL_4 = "EMAILADDRESS";
    public static final String Student_Table_COL_5 = "TYPEOFDEGREE";
    public static final String Student_Table_COL_6 = "COURSETITLE";
    public static final String Student_Table_COL_7 = "YEAROFGRAD";
    public static final String Student_Table_COL_8 = "PASSTYPE";

    public String email;
    public String pass;

    public DatabaseClass(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + STUDENT_TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT,FIRSTNAME TEXT,SURNAME TEXT,EMAILADDRESS TEXT,TYPEOFDEGREE TEXT,COURSETITLE TEXT,YEAROFGRAD TEXT,PASSTYPE TEXT)");
        db.execSQL("create table " + EVENTS_TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT,TITLE TEXT,TYPE TEXT,LOCATION TEXT,STARTDATE TEXT, EVENTSTATUS TEXT, EVENTATTENDED TEXT)");
        db.execSQL("create table " + USER_TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT,EMAIL TEXT,PASSWORD TEXT)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + EVENTS_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + STUDENT_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE_NAME);
        onCreate(db);
    }


//User Data / Login Related Methods

    //Method to insert data to Db
    public void insertData(String email, String password) {

        SQLiteDatabase db = this.getWritableDatabase();//create database and table
        ContentValues contentValues = new ContentValues();

        contentValues.put(EMAIL, email);
        contentValues.put(PASSWORD, password);

        //   Log.d("PKA", "data written to DB");
        db.insert(USER_TABLE_NAME, null, contentValues);
        db.close();
    }

    public boolean ValidateCredentials(String uname, String pwd) {

        String emailRead, pwdRead;
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "select EMAIL, PASSWORD from " + USER_TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                emailRead = cursor.getString(0);
                pwdRead = cursor.getString(1);

                if (uname.equals(emailRead) && pwd.equals(pwdRead)) {
                    db.close();
                    return true;
                    //  break;
                }
            }
            while (cursor.moveToNext());
        }
        db.close();
        return false;
    }

    public int UpdateUserTable(String uname, String pwd) {

        String emailRead, pwdRead;
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        //Creating the KeyValue Pairs
        contentValues.put(PASSWORD, pwd);

        //Update the database
        //Ret = 1 on Success / ret = 0 on failure
        int ret = db.update(USER_TABLE_NAME, contentValues, "EMAIL = ?", new String[]{uname});
        //Log.d("PKA", "ret = "+ ret);
        db.close();
        return ret;
    }

//
//Methods for Events Home

    public void insertEventData(String title, String type, String location, String startdate, String status, String Choice) {
        SQLiteDatabase db = this.getWritableDatabase();//create database and table
        //String EventTableName = Choice + EVENTS_TABLE_NAME;
        //   db.execSQL("create table " + EVENTS_TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT,TITLE TEXT,TYPE TEXT,LOCATION TEXT,STARTDATE TEXT, EVENTSTATUS TEXT, EVENTATTENDED TEXT)");

        ContentValues contentValues = new ContentValues();
        contentValues.put(Event_Table_COL_1, title);
        contentValues.put(Event_Table_COL_2, type);
        contentValues.put(Event_Table_COL_3, location);
        contentValues.put(Event_Table_COL_4, startdate);
        contentValues.put(Event_Table_COL_5, status);
        contentValues.put(Event_Table_COL_6, "Not Attended");

        db.insert(EVENTS_TABLE_NAME, null, contentValues);
        db.close();
    }


    public void insertStudentData(String firstname, String surname, String email, String typeofdeg, String coursetitle, String yearofgrad, String passtype, String Choice) {
        Choice = Choice.replaceAll(" ", "_");

        SQLiteDatabase db = this.getWritableDatabase();//create database and table
        EventTableName = Choice + "_" + EVENTS_TABLE_NAME;

        db.execSQL("create table IF NOT EXISTS " + EventTableName + "(ID INTEGER PRIMARY KEY AUTOINCREMENT,FIRSTNAME TEXT,SURNAME TEXT,EMAILADDRESS TEXT,TYPEOFDEGREE TEXT,COURSETITLE TEXT,YEAROFGRAD TEXT,PASSTYPE TEXT)");

        ContentValues contentValues = new ContentValues();

        contentValues.put(Student_Table_COL_2, firstname);
        contentValues.put(Student_Table_COL_3, surname);
        contentValues.put(Student_Table_COL_4, email);
        contentValues.put(Student_Table_COL_5, typeofdeg);
        contentValues.put(Student_Table_COL_6, coursetitle);
        contentValues.put(Student_Table_COL_7, yearofgrad);
        contentValues.put(Student_Table_COL_8, passtype);
        db.insert(EventTableName, null, contentValues);
        db.close();
    }

    public ArrayList<String> getAll() {
        ArrayList<String> list = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        db.beginTransaction();

        String completedCheck = "Complete";
        try {
            String selectQuery = "SELECT * FROM " + EVENTS_TABLE_NAME + " where EVENTSTATUS ='" + completedCheck + "'";
            Cursor cursor = db.rawQuery(selectQuery, null);


            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String title = cursor.getString(cursor.getColumnIndex("TITLE"));
                    list.add(title);
                }
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.endTransaction();
            db.close();
        }
        return list;
    }


    public ArrayList<String> getEndAll() {
        ArrayList<String> list = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        db.beginTransaction();

        String eventAttended = "Attended";
        try {
            String selectQuery = "SELECT * FROM " + EVENTS_TABLE_NAME + " where EVENTATTENDED ='" + eventAttended + "'";
            Cursor cursor = db.rawQuery(selectQuery, null);


            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String title = cursor.getString(cursor.getColumnIndex("TITLE"));
                    list.add(title);
                }
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.endTransaction();
            db.close();
        }
        return list;
    }

    public void startEvent(String eventStartedTxt, String Value) {
        SQLiteDatabase db = this.getReadableDatabase();//create database and table

        ContentValues contentValues = new ContentValues();
        contentValues.put(Event_Table_COL_6, eventStartedTxt);
        db.update(EVENTS_TABLE_NAME, contentValues, "TITLE= ?", new String[]{Value});
        db.close();

    }

    public void endEvent(String EventEndTxt, String ValueEnd) {
        SQLiteDatabase db = this.getReadableDatabase();//create database and table

        ContentValues contentValues = new ContentValues();
        contentValues.put(Event_Table_COL_6, EventEndTxt);
        db.update(EVENTS_TABLE_NAME, contentValues, "TITLE= ?", new String[]{ValueEnd});
        db.close();

    }

    //Retrive Data2
    //Coming in from Joshuas code
    public List<EventDetails> getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();
        List<EventDetails> eventItems = new ArrayList<EventDetails>();

        String selectQ = "SELECT * FROM " + EVENTS_TABLE_NAME;
        Cursor cursor = db.rawQuery(selectQ, new String[]{});
        if (cursor.moveToFirst()) {
            do {

                EventDetails eventDetails = new EventDetails();

                eventDetails.setID(Integer.parseInt(cursor.getString(0)));
                eventDetails.setEventTitle(cursor.getString(1));
                eventDetails.setEventType(cursor.getString(2));
                eventDetails.setEventLoc(cursor.getString(3));
                eventDetails.setEventDate(cursor.getString(4));
                eventDetails.setEventStatus(cursor.getString(5));
                eventDetails.setEventAtt(cursor.getString(6));

                eventItems.add(eventDetails);

            } while (cursor.moveToNext());
        }

        return eventItems;
    }

    //Update Event
    public void updateEvent(String title, String type, String location, String startdate, String status) {
        SQLiteDatabase db = this.getReadableDatabase();//create database and table

        ContentValues contentValues = new ContentValues();
        contentValues.put(Event_Table_COL_1, title);
        contentValues.put(Event_Table_COL_2, type);
        contentValues.put(Event_Table_COL_3, location);
        contentValues.put(Event_Table_COL_4, startdate);
        contentValues.put(Event_Table_COL_5, status);

        db.update(EVENTS_TABLE_NAME, contentValues, "TITLE =?", new String[]{title});
        db.close();

    }

    //Method to delete an Event
    public boolean deleteEvent (String eventname){
        /////
        String titleRead, eventattendedRead;
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "select TITLE, EVENTATTENDED from " + EVENTS_TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                titleRead = cursor.getString(0);
                eventattendedRead = cursor.getString(1);

                //For an event which is going on
                if (titleRead.equals(eventname) && eventattendedRead.equals("Attended")) {
                    db.close();
                    return true;
                    //  break;
                }
                //For an event which is not started yet
                else if (titleRead.equals(eventname) && eventattendedRead.equals("Not Attended")) {
                    db.delete(EVENTS_TABLE_NAME, "TITLE =?", new String[]{eventname});
                    db.close();
                    return false;
                }
                //For an event which Ended
                else if (titleRead.equals(eventname) && eventattendedRead.equals("Event Ended")) {
                    db.delete(EVENTS_TABLE_NAME, "TITLE =?", new String[]{eventname});
                    eventname = eventname.replaceAll(" ", "_");
                    //Now drop the xxx_events_table Table
                    EventTableName = eventname + "_" + EVENTS_TABLE_NAME;
                    db.execSQL("DROP TABLE IF EXISTS " + EventTableName);
                    db.close();
                    return false;
                }

            }
            while (cursor.moveToNext());
        }
        db.close();
        return false;
    }

    public boolean ReturnToEventsHome(String pwd) {

        String pwdRead;
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "select PASSWORD from " + USER_TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);


        if(cursor.moveToFirst()) {
            do {

                pwdRead = cursor.getString(0);
                Log.d("PKA", pwdRead);
                Log.d("PKA", "passwd = " +pwd);
                if (pwdRead.equals(pwd)) {
                    db.close();
                    return true;
                    //  break;
                }
            }
            while (cursor.moveToNext());
        }
        db.close();
        return false;

    }



    public ArrayList<String> getStudent(String eventName){
        ArrayList<String> st = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        db.beginTransaction();


        try {
            Log.d("start", "working");
            eventName = eventName.replaceAll(" ", "_");
            //Now drop the xxx_events_table Table
            EventTableName = eventName + "_" + EVENTS_TABLE_NAME;
            String selectQuery = "SELECT * FROM " + EventTableName;
            Cursor cursor = db.rawQuery(selectQuery, null);

            Log.d("PKA", "working1");
            if(cursor.moveToFirst()) {
                do {
                    String FirstName = cursor.getString(cursor.getColumnIndex("FIRSTNAME"));
                    st.add(FirstName);
                    String surname = cursor.getString(cursor.getColumnIndex("SURNAME"));
                    st.add(surname);
                    String courseTitle = cursor.getString(cursor.getColumnIndex("COURSETITLE"));
                    st.add(courseTitle);
                    String passport = cursor.getString(cursor.getColumnIndex("PASSTYPE"));
                    st.add(passport);

                }
                while (cursor.moveToNext());
            }


            db.setTransactionSuccessful();
        }catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            db.endTransaction();
            db.close();
        }

        for (String student : st){
            Log.d("PKA", student);
        }

        return st;
    }


}



